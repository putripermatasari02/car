<h2 align="center">Jakarta Car Rental(CodeIgniter 3)</h2>

Aplikasi JCR menggunakan framework CodeIgniter 3. Dengan multi user (admin, pemilik rental dan customer). 
