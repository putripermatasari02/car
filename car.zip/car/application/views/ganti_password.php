<body>
  <div id="app">
    <section class="section">
      <div class="container mt-5">
        <div class="row">
          <div class="col-12 col-sm-10 offset-sm-1 col-md-8 offset-md-2 col-lg-8 offset-lg-2 col-xl-6 offset-xl-3">
            <div class="login-brand">
              <!-- <img src="<?php echo base_url('assets/assets_stisla/') ?>/assets/img/stisla-fill.svg" alt="logo" width="100" class="shadow-light rounded-circle"> -->
            </div>

            <div class="card card-primary">
              <div class="card-header">
                <h4>Ganti Password</h4>
              </div>

              <span class="m-2"><?php echo $this->session->flashdata('pesan') ?></span>

              <div class="card-body">
                <form method="POST" action="<?php echo base_url('auth/ganti_password_aksi') ?>">

                  <div class="form-group">
                    <div class="d-block">
                      <label for="pass_baru" class="control-label">Password Baru</label>
                    </div>
                    <input id="pass_baru" type="password" class="form-control" name="pass_baru" tabindex="2"> <?php echo form_error('pass_baru', '<div class="text-small text-danger">', '</div>') ?>
                  </div>

                  <div class="form-group">
                    <div class="d-block">
                      <label for="ulang_pass" class="control-label">Ulangi Password</label>
                    </div>
                    <input id="ulang_pass" type="password" class="form-control" name="ulang_pass" tabindex="2"> <?php echo form_error('ulang_pass', '<div class="text-small text-danger">', '</div>') ?>
                  </div>


                  <div class="form-group">
                    <button type="submit" class="btn btn-primary btn-lg btn-block" tabindex="4">
                      Ganti Password
                    </button>
                  </div>
                </form>

              </div>
            </div>
            <div class="simple-footer">
              Copyright &copy; 2024 Putri Permata Sari</a>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
