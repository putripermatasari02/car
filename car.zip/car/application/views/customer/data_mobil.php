<!--== Page Title Area Start ==-->
<section id="page-title-area" class="section-padding overlay">
	<div class="container">

		<div class="row">
			<!-- Page Title Start -->
			<div class="col-lg-12">
				<div class="section-title  text-center">
					<h2>Pilihan Mobil</h2>
					<span class="title-line"><i class="fa fa-car"></i></span>
					<p>Berbagai pilihan mobil terbaik untuk menemani perjalanan anda</p>
				</div>
			</div>
			<!-- Page Title End -->
		</div>
	</div>
</section>
<!--== Page Title Area End ==-->

<!--== Car List Area Start ==-->
<section id="car-list-area" class="section-padding">
	<div class="container">
		<?php echo $this->session->flashdata('pesan') ?>
		<div class="row">
			<!-- Choose Area Content Start -->
			<div class="col-lg-12">
				<div class="choose-ur-cars">
					<div class="row">
						<div class="col-lg-3">
							<!-- Choose Filtering Menu Start -->

							<div class="home2-car-filter">
								<a href="#" data-filter="*" class="active">all</a>

								<?php foreach ($type as $tp) : ?>
									<a href="#" data-filter=".<?php echo $tp->kode_type ?>"><?php echo $tp->nama_type ?></a>
								<?php endforeach; ?>
							</div>
							<!-- Choose Filtering Menu End -->
						</div>

						<div class="col-lg-9">
							<!-- Choose Cars Content-wrap -->
							<div class="row popular-car-gird">

								<?php foreach ($mobil as $mb) : ?>
									<!-- Single Popular Car Start -->
									<div class="col-lg-6 col-md-6 <?php echo $mb->kode_type ?>">
										<div class="single-popular-car">
											<div class="p-car-thumbnails">
												<a class="car-hover" href="<?php echo base_url('assets/upload/' . $mb->gambar) ?>">
													<img style="height: 300px" src="<?php echo base_url('assets/upload/' . $mb->gambar) ?>" alt="<?php echo $mb->merk ?>">
												</a>
											</div>

											<div class="car-list-info without-bar">
												<h2><a href="#"><?php echo $mb->merk ?></a></h2>
												<h5>Rp. <?php echo number_format($mb->harga, 0, ',', '.') ?>/Hari</h5>
												<p class="text-dark font-italic">Mobil ini disediakan oleh <?php echo $mb->nama_rental ?></p>
												<ul class="car-info-list">
													<li><?php
														if ($mb->ac == "1") {
															echo "<i class='fa fa-check-square text-warning'></i>";
														} else {
															echo "<i class='fa fa-times-circle text-danger'></i>";
														}
														?> AC
													</li>
													<li><?php
														if ($mb->supir == "1") {
															echo "<i class='fa fa-check-square text-warning'></i>";
														} else {
															echo "<i class='fa fa-times-circle text-danger'></i>";
														}
														?> Supir
													</li>
													<li><?php
														if ($mb->mp3_player == "1") {
															echo "<i class='fa fa-check-square text-warning'></i>";
														} else {
															echo "<i class='fa fa-times-circle text-danger'></i>";
														}
														?> MP3 Player
													</li>
													<li><?php
														if ($mb->central_lock == "1") {
															echo "<i class='fa fa-check-square text-warning'></i>";
														} else {
															echo "<i class='fa fa-times-circle text-danger'></i>";
														}
														?> Central Lock
													</li>
												</ul>
												<?php
												if ($mb->status == "1") {
													echo anchor('customer/rental/tambah_rental/' . $mb->id_mobil, '<span class="rent-btn">Sewa</span>');
												} else {
													echo "<span class='rent-btn'>Tidak Tersedia</span>";
												}

												?>


												<a href="<?php echo base_url('customer/data_mobil/detail_mobil/' . $mb->id_mobil) ?>" class="rent-btn">Detail</a>

											</div>
										</div>
									</div>
								<?php endforeach ?>
								<!-- Single Car End -->
							</div>
						</div>
					</div>
				</div>
			</div>
</section>