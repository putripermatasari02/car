  <!--== Footer Area Start ==-->
  <section id="footer-area">
      <!-- Footer Widget Start -->
      <div class="footer-widget-area">
          <div class="container">
              <div class="row">
                  <!-- Single Footer Widget Start -->
                  <div class="col-lg-6 col-md-6">
                      <div class="single-footer-widget">
                          <h2>Tentang Kami</h2>
                          <div class="widget-body">
                              <img src="<?php echo base_url() ?>assets/assets_shop/img/JCR-Logo1.png" style="height: 100px;" alt="JSOFT">
                              <p>Jakarta Car Rental adalah Usaha penyewaan mobil berkualitas dengan harga terjangkau. Anda bisa memilih mobil sesuai dengan keinginan anda. </p>
                          </div>
                      </div>
                  </div>
                  <!-- Single Footer Widget End -->


                  <!-- Single Footer Widget Start -->
                  <div class="col-lg-6 col-md-6">
                      <div class="single-footer-widget">
                          <h2>Hubungi Kami</h2>
                          <div class="widget-body">
                              <p>Hubungi kami untuk mengetahu informasi lebih lanjut. Dapatkan layanan terbaik dengan menyewa mobil pada Jakarta Car Rental.</p>

                              <ul class="get-touch">
                                  <li><i class="fa fa-map-marker"></i> Jl. Kramat Raya No.18</li>
                                  <li><i class="fa fa-mobile"></i> +62 81381294390</li>
                                  <li><i class="fa fa-envelope"></i> Jakartacar@gmail.com</li>
                              </ul>
                              <!-- <a href="https://goo.gl/maps/b5mt45MCaPB2" class="map-show" target="_blank">Show Location</a> -->
                          </div>
                      </div>
                  </div>
                  <!-- Single Footer Widget End -->
              </div>
          </div>
      </div>
      <!-- Footer Widget End -->

      <!-- Footer Bottom Start -->
      <div class="footer-bottom-area">
          <div class="container">
              <div class="row">
                  <div class="col-lg-12 text-center">
                      <p>
                          Copyright &copy;<script>
                              document.write(new Date().getFullYear());
                          </script> Putri Permata Sari</a>
                          </p>
                  </div>
              </div>
          </div>
      </div>
      <!-- Footer Bottom End -->
  </section>
  <!--== Footer Area End ==-->

  <!--== Scroll Top Area Start ==-->
  <div class="scroll-top">
      <img src="<?php echo base_url() ?>assets/assets_shop/img/scroll-top.png" alt="JSOFT">
  </div>
  <!--== Scroll Top Area End ==-->

  <!--=======================Javascript============================-->
  <!--=== Jquery Min Js ===-->
  <script src="<?php echo base_url() ?>assets/assets_shop/js/jquery-3.2.1.min.js"></script>
  <!--=== Jquery Migrate Min Js ===-->
  <script src="<?php echo base_url() ?>assets/assets_shop/js/jquery-migrate.min.js"></script>
  <!--=== Popper Min Js ===-->
  <script src="<?php echo base_url() ?>assets/assets_shop/js/popper.min.js"></script>
  <!--=== Bootstrap Min Js ===-->
  <script src="<?php echo base_url() ?>assets/assets_shop/js/bootstrap.min.js"></script>
  <!--=== Gijgo Min Js ===-->
  <script src="<?php echo base_url() ?>assets/assets_shop/js/plugins/gijgo.js"></script>
  <!--=== Vegas Min Js ===-->
  <script src="<?php echo base_url() ?>assets/assets_shop/js/plugins/vegas.min.js"></script>
  <!--=== Isotope Min Js ===-->
  <script src="<?php echo base_url() ?>assets/assets_shop/js/plugins/isotope.min.js"></script>
  <!--=== Owl Caousel Min Js ===-->
  <script src="<?php echo base_url() ?>assets/assets_shop/js/plugins/owl.carousel.min.js"></script>
  <!--=== Waypoint Min Js ===-->
  <script src="<?php echo base_url() ?>assets/assets_shop/js/plugins/waypoints.min.js"></script>
  <!--=== CounTotop Min Js ===-->
  <script src="<?php echo base_url() ?>assets/assets_shop/js/plugins/counterup.min.js"></script>
  <!--=== YtPlayer Min Js ===-->
  <script src="<?php echo base_url() ?>assets/assets_shop/js/plugins/mb.YTPlayer.js"></script>
  <!--=== Magnific Popup Min Js ===-->
  <script src="<?php echo base_url() ?>assets/assets_shop/js/plugins/magnific-popup.min.js"></script>
  <!--=== Slicknav Min Js ===-->
  <script src="<?php echo base_url() ?>assets/assets_shop/js/plugins/slicknav.min.js"></script>

  <!--=== Mian Js ===-->
  <script src="<?php echo base_url() ?>assets/assets_shop/js/main.js"></script>

  </body>

  </html>
