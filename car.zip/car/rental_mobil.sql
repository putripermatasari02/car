-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 02, 2023 at 02:44 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.1.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rental_mobil`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id_admin` int(11) NOT NULL,
  `nama_admin` varchar(120) NOT NULL,
  `username` varchar(120) NOT NULL,
  `password` varchar(120) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `id_customer` int(11) NOT NULL,
  `nama` varchar(120) NOT NULL,
  `nama_rental` varchar(120) NOT NULL,
  `username` varchar(120) NOT NULL,
  `alamat` varchar(120) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `no_telp` varchar(20) NOT NULL,
  `no_ktp` varchar(50) NOT NULL,
  `password` varchar(120) NOT NULL,
  `role_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id_customer`, `nama`, `nama_rental`, `username`, `alamat`, `gender`, `no_telp`, `no_ktp`, `password`, `role_id`) VALUES
(1, 'Admin1', '', 'Admin1', 'Jakarta', 'Laki-laki', '081381294290', '3172065602030003', 'e10adc3949ba59abbe56e057f20f883e', 1),
(2, 'JKT Rental', 'JKT Rental', 'JKT_Rental', 'Jl. Perintis Kemerdekaan No.23', '', '087654324561', '3172065602030002', '123456', 3),
(3, 'Gading Car Rental', 'Gading Car Rental', 'Gdg_Rental', 'Jl. Taman Gading Indah 2 D10', '', '089764538902', '314256780003', '123456', 3),
(4, 'Priok Travel', 'Priok Travel', 'Priok_Travel', 'Jl. Swaswmbada 7 No.102', '', '087865432901', '328905670009', '123456', 3),
(5, 'Cempaka Drivers', 'Cempaka Drivers', 'Cempaka_drv', 'Jl. Cempaka Putih Barat 5A', '', '089765890342', '324578900003', '123456', 3),
(6, 'Dove Car', 'Dove Car', 'Dove_Car', 'Jl. Inspeksi Kali Sunter No.89', '', '085678905432', '332456780001', '123456', 3),
(24, 'Alya Yunita', '', 'alyayun', 'Jakarta Utara', 'Perempuan', '081381294298', '3278095600030001', 'e10adc3949ba59abbe56e057f20f883e', 2),
(25, 'Putri Permata Sari', '', 'putri', 'Jakarta Pusat', 'Perempuan', '085781544526', '3328272878928912', '82682943a05de360abb183236c632bd6', 2);

-- --------------------------------------------------------

--
-- Table structure for table `mobil`
--

CREATE TABLE `mobil` (
  `id_mobil` int(11) NOT NULL,
  `nama_rental` varchar(120) NOT NULL,
  `kode_type` varchar(120) NOT NULL,
  `merk` varchar(120) NOT NULL,
  `no_plat` varchar(20) NOT NULL,
  `warna` varchar(20) NOT NULL,
  `tahun` varchar(4) NOT NULL,
  `status` varchar(50) NOT NULL,
  `harga` int(11) NOT NULL,
  `denda` int(11) NOT NULL,
  `ac` int(11) NOT NULL,
  `supir` int(11) NOT NULL,
  `mp3_player` int(11) NOT NULL,
  `central_lock` int(11) NOT NULL,
  `gambar` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `mobil`
--

INSERT INTO `mobil` (`id_mobil`, `nama_rental`, `kode_type`, `merk`, `no_plat`, `warna`, `tahun`, `status`, `harga`, `denda`, `ac`, `supir`, `mp3_player`, `central_lock`, `gambar`) VALUES
(21, 'Priok Travel', 'SDN', 'Honda City', 'B 1476 UBK', 'Putih', '2020', '0', 400000, 150000, 1, 0, 1, 1, 'honda-city-generasi-kelima-bermesin-turbo-mengaspal-di-thailand-nKxUNH0qVW1.jpg'),
(22, 'Gading Car Rental', 'SDN', 'Toyota Vios', 'B 3345 UCK', 'Merah', '2020', '1', 350000, 100000, 1, 1, 0, 1, 'Toyota_Vios_2020__Small_Sedan_Paling_Eksis_(1).png'),
(23, 'Dove Car', 'HB', 'Honda Brio RS', 'B 5643 TIK', 'Kuning', '2021', '1', 200000, 100000, 1, 0, 1, 0, 'Brio1.jpg'),
(24, 'Dove Car', 'HB', 'Nissan March', 'B 4901 TUG', 'Pink', '2017', '1', 200000, 100000, 1, 0, 1, 0, 'Nissan-March-Facelift-20171.jpg'),
(25, 'Gading Car Rental', 'HB', 'Toyota Agya', 'B 2235 STK', 'Silver', '2021', '1', 250000, 100000, 1, 1, 1, 0, 'Toyota_Agya.jpg'),
(26, 'Priok Travel', 'MPV', 'Daihatsu Xenia', 'B 7869 UKT', 'Merah', '2015', '1', 300000, 100000, 1, 1, 0, 0, 'MPV_Daihatsu_Xenia_2015_-_Red1.png'),
(27, 'Cempaka Drivers', 'MPV', 'Toyota Avanza', 'B 7786 BTU', 'Putih', '2014', '1', 300000, 100000, 1, 1, 0, 0, 'MPV_Toyota_Avanza_2014_-_White2.png'),
(28, 'Cempaka Drivers', 'SUV', 'Toyota Rush', 'B 5289 TPR', 'Hitam', '2012', '1', 450000, 100000, 1, 1, 1, 1, 'SUV_Toyota_Rush_2012_-_Black1.jpg'),
(29, 'Priok Travel', 'PUD', 'Mitsubishi Strada', 'B 6429 TBK', 'Silver', '2017', '1', 450000, 100000, 1, 0, 1, 1, 'PUD_Mitsubishi_Strada_2017_-_White2.png'),
(30, 'Priok Travel', 'PUS', 'Daihatsu Gran Max Pickup', 'B 1452 UJK', 'Putih', '2018', '1', 250000, 100000, 0, 0, 0, 0, 'Daihatsu_Gran_Max_Pick_Up.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `id_payment` int(11) NOT NULL,
  `nama_payment` varchar(120) NOT NULL,
  `key_payment` varchar(120) NOT NULL,
  `atas_nama` varchar(120) DEFAULT NULL,
  `nama_rental` varchar(120) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`id_payment`, `nama_payment`, `key_payment`, `atas_nama`, `nama_rental`) VALUES
(1, 'OVO', '087689329032', 'JKT Rental', 'JKT Rental'),
(2, 'BCA', '1660628309', 'JKT Rental', 'JKT Rental'),
(3, 'Dana', '087689329032', 'JKT Rental', 'JKT Rental'),
(4, 'Go-Pay', '087689329032', 'JKT Rental', 'JKT Rental'),
(5, 'BCA', '7770908394', 'Gading Car Rental', 'Gading Car Rental'),
(6, 'BCA', '8990888309', 'Priok Travel', 'Priok Travel'),
(7, 'BCA', '9980328390', 'Cempaka Drivers', 'Cempaka Drivers'),
(8, 'DANA', '089764538902', 'Gading Car Rental', 'Gading Car Rental'),
(9, 'OVO', '089764538902', 'Gading Car Rental', 'Gading Car Rental'),
(10, 'Go-Pay', '089764538902', 'Gading Car Rental', 'Gading Car Rental'),
(12, 'DANA', '087865432901', 'Priok Travel', 'Priok Travel'),
(13, 'Go-Pay', '087865432901', 'Priok Travel', 'Priok Travel'),
(14, 'OVO', '087865432901', 'Priok Travel', 'Priok Travel'),
(15, 'DANA', '089765890342', 'Cempaka Drivers', 'Cempaka Drivers'),
(16, 'OVO', '089765890342', 'Cempaka Drivers', 'Cempaka Drivers'),
(17, 'Go-Pay', '089765890342', 'Cempaka Drivers', 'Cempaka Drivers'),
(18, 'DANA', '085678905432', 'Dove Car', 'Dove Car'),
(19, 'OVO', '085678905432', 'Dove Car', 'Dove Car'),
(20, 'Go-Pay', '085678905432', 'Dove Car', 'Dove Car');

-- --------------------------------------------------------

--
-- Table structure for table `rental`
--

CREATE TABLE `rental` (
  `id_rental` int(11) NOT NULL,
  `id_customer` int(11) NOT NULL,
  `tanggal_rental` date NOT NULL,
  `tanggal_kembali` date NOT NULL,
  `tanggal_pengembalian` date NOT NULL,
  `status_rental` varchar(50) NOT NULL,
  `status_pengembalian` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

CREATE TABLE `transaksi` (
  `id_rental` int(11) NOT NULL,
  `id_customer` int(11) NOT NULL,
  `id_mobil` int(11) NOT NULL,
  `nama_rental` varchar(120) NOT NULL,
  `tanggal_rental` date NOT NULL,
  `tanggal_kembali` date NOT NULL,
  `harga` int(11) NOT NULL,
  `denda` int(11) NOT NULL,
  `total_denda` varchar(120) NOT NULL DEFAULT '0',
  `tanggal_pengembalian` date NOT NULL,
  `status_pengembalian` varchar(50) NOT NULL,
  `status_rental` varchar(50) NOT NULL,
  `bukti_pembayaran` varchar(130) NOT NULL,
  `status_pembayaran` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `transaksi`
--

INSERT INTO `transaksi` (`id_rental`, `id_customer`, `id_mobil`, `nama_rental`, `tanggal_rental`, `tanggal_kembali`, `harga`, `denda`, `total_denda`, `tanggal_pengembalian`, `status_pengembalian`, `status_rental`, `bukti_pembayaran`, `status_pembayaran`) VALUES
(22, 24, 22, 'Gading Car Rental', '2023-06-30', '2023-07-02', 350000, 100000, '0', '2023-07-02', 'Kembali', 'Selesai', 'lrs_rental_drawio_(3).png', 1),
(23, 25, 21, 'Priok Travel', '2023-07-01', '2023-07-03', 400000, 150000, '0', '2023-07-03', 'Kembali', 'Selesai', 'lrs_rental_drawio_(3)1.png', 1),
(24, 25, 21, 'Priok Travel', '2023-07-01', '2023-07-04', 400000, 150000, '0', '0000-00-00', 'Belum Kembali', 'Belum Selesai', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `type`
--

CREATE TABLE `type` (
  `id_type` int(11) NOT NULL,
  `kode_type` varchar(10) NOT NULL,
  `nama_type` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `type`
--

INSERT INTO `type` (`id_type`, `kode_type`, `nama_type`) VALUES
(1, 'SDN', 'Sedan'),
(2, 'HB', 'Hatchback'),
(3, 'MPV', 'Multi Purpose Vehicle'),
(4, 'SUV', 'Sport Utility Vehicle'),
(5, 'PUS', 'Pick-Up Single Cabin'),
(6, 'PUD', 'Pick-Up Double Cabin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id_admin`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id_customer`);

--
-- Indexes for table `mobil`
--
ALTER TABLE `mobil`
  ADD PRIMARY KEY (`id_mobil`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`id_payment`);

--
-- Indexes for table `rental`
--
ALTER TABLE `rental`
  ADD PRIMARY KEY (`id_rental`);

--
-- Indexes for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`id_rental`);

--
-- Indexes for table `type`
--
ALTER TABLE `type`
  ADD PRIMARY KEY (`id_type`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id_admin` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `id_customer` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `mobil`
--
ALTER TABLE `mobil`
  MODIFY `id_mobil` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `id_payment` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `rental`
--
ALTER TABLE `rental`
  MODIFY `id_rental` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `transaksi`
--
ALTER TABLE `transaksi`
  MODIFY `id_rental` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `type`
--
ALTER TABLE `type`
  MODIFY `id_type` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
